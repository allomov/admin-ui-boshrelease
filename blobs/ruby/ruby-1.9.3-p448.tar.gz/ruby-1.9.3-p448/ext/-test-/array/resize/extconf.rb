create_makefile("-test-/array/resize")
